using System.Collections.Generic;
using UnityEngine;


public class Weapon : ScriptableObject
{
    public enum AttackType : byte { Single, Multiple}

    [SerializeField] int damage = 1;
    [SerializeField] float range = 1;
    [SerializeField] float cooldown = 1;
}
[System.Serializable]
public class CharacterWeaponContext : ICharacterInitializable<CharacterWeapon>
{
    public Weapon data;
    public BoxCollider2D detector;
    public CharacterWeapon characterWeapon;

    public CharacterWeapon Initialize(CharacterController controller)
    {
        characterWeapon = new CharacterWeapon(controller, data, detector);
        return characterWeapon;
    }
}
public class CharacterWeapon
{
    Weapon data;
    CharacterController owner;
    List<CharacterController> targets;

    public CharacterWeapon(CharacterController controller, Weapon data, BoxCollider2D detector)
    {
        this.data = data;
        owner = controller;
        targets = new List<CharacterController>();
    }

    public Collider2D? DetectCollider(Vector3 offset, Vector2 direction, float distance, LayerMask layers)
    {
        RaycastHit2D hit = Physics2D.Raycast(offset, direction, distance, layers);
        return hit.collider;
    }

}
