﻿public interface ICharacterInitializable<T>
{
    T Initialize(CharacterController controller);
}
