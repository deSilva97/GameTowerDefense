using UnityEngine;

[System.Serializable]
public class CharacterMovmentContext : ICharacterInitializable<CharacterMovment>
{
    public CharacterMovment.MovmentForm form;
    public float speed = 1;
    public Vector3 offset = Vector3.zero;
    public CharacterMovment characterMovment;

    public CharacterMovment Initialize(CharacterController controller)
    {
        characterMovment = new CharacterMovment(controller.transform, speed);
        return characterMovment;
    }
}
public class CharacterMovment
{
    public enum MovmentForm { Left = -1, Right = 1}

    Transform character;
    float speed;

    public CharacterMovment(Transform character, float speed)
    {
        this.character = character;
        this.speed = speed;
    }

    public void Move(MovmentForm f)
    {
        character.Translate(character.right * (int)f * speed * Time.deltaTime);
    }

    public void TryToMove(MovmentForm f, Vector3 offset, float distance, LayerMask obstacles)
    {
        int direction = (int)f;
        offset.Set(offset.x * direction, offset.y, offset.z);

        RaycastHit2D hit = Physics2D.Raycast(offset, Vector2.right * direction, distance, obstacles);

        Debug.DrawLine(offset, offset  + Vector3.right * distance * direction);

        if (hit.collider == null)
        {
            Move(f);
        }
        else
        {
            Debug.Log("Movimiento bloqueado por: " + hit.collider.name);
        }
    }
}

