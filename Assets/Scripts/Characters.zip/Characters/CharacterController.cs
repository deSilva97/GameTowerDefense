using UnityEngine;

public class CharacterController : MonoBehaviour
{

    [SerializeField] CharacterMovmentContext movmentContext;
    [SerializeField] CharacterWeaponContext weaponContextLeft;
    [SerializeField] LayerMask obstacleLayer; // Para detectar qu� capas bloquean el paso
    public CharacterMovment myCharacterMovment { get; private set; }
    public CharacterWeapon myCharacterWeaponLeft { get; private set; }


    public bool CanMove() => 
        !myCharacterWeaponLeft.DetectCollider(transform.position, Vector2.left, 1f, obstacleLayer);

    private void Start()
    {
        myCharacterMovment = movmentContext.Initialize(this);
        myCharacterWeaponLeft = weaponContextLeft.Initialize(this);
    }

    private void Update()
    {
        if(CanMove())
            myCharacterMovment.TryToMove(
                movmentContext.form, 
                transform.position + movmentContext.offset, 1f, obstacleLayer);
    }

}

